# -*- coding: utf-8 -*-
"""Многополигональные предметы объекта (по визуализации fotoshop.jpg), которых нет в библиотеке движка.
Подключается движком (engine/ifc/scene3d.py): ITEMS/LIGHTS с полем ext3d='<функция>', materials(M, T), build(S).
Оси: x — от стены кухни к камере, y — от левой стены, z — вверх; мм."""
import math
import os

import numpy as np
from PIL import Image

import model as D
from ifc import hp as H
from ifc.m3d import box, prism, Elem

HERE = os.path.dirname(os.path.abspath(__file__))
V = np.asarray
TOP = 910                      # верх столешницы
UP0, UP1 = 1680, 2950          # верхние шкафы
FRONT_T = 20                   # толщина фасада
GAP = 1.5                      # половина зазора между фасадами


# ================================================================ материалы
def materials(M, T):
    from ifc.scene3d import mkey
    from scipy.ndimage import gaussian_filter
    tm = M.tex_material
    # фасады: эмаль матовая синяя (по кадру), шейкер
    tm('FRONT', 'Фасады МДФ «шейкер», эмаль матовая NCS S 4040-R80B', 'front_blue.jpg',
       T.paint(800, 800, 1.0, (46, 84, 140), 7, gradient=False), (800, 800), spec=0.18)
    # декоративная штукатурка стен: светло-серая с серебристыми разводами (бесшовная)
    rng = np.random.default_rng(31)
    n = 1000                                               # 1 px = 1 мм, повтор 1000 мм (UV стен — s/1000)
    def fb(sig):
        f = gaussian_filter(rng.standard_normal((n, n)), sig, mode='wrap')
        return (f - f.mean()) / f.std()
    a = fb(110) * 0.75 + fb(40) * 0.45 + fb(12) * 0.2
    blot = np.clip((a - 0.55) * 0.9, 0, 1) ** 1.3          # облачные разводы
    fine = fb(1.5)
    base = np.array([229, 229, 231], np.float32)
    blotc = np.array([205, 206, 209], np.float32)
    img = base * (1 - blot[..., None]) + blotc * blot[..., None]
    img += (fine * 1.6)[..., None]
    edge = np.clip(1 - np.abs(a - 0.6) * 10, 0, 1) * 6     # серебристый кант разводов
    img += edge[..., None]
    tm(mkey('С1'), 'С1 Декоративная штукатурка светло-серая с разводами', 'c1_plaster.jpg', img, (1000, 1000),
       spec=0.2, ifc_mat='С1 Декоративная штукатурка')
    # фартук: плитка «звезда-крест», раппорт 250×250 — снят с визуализации заказчика (выровнен по свету)
    tile = np.asarray(Image.open(os.path.join(HERE, 'tex', 'star_tile_250.png')).convert('RGB')).astype(np.float32)
    tile = np.tile(tile, (4, 4, 1))                     # UV фартука — 4×4 плитки на текстуру (как в движке)
    tm(mkey('С2'), 'С2 Плитка «звезда-крест» 250×250, мрамор Nero Marquina / серый / белый', 'c2_star_tile.jpg', tile,
       (1000, 1000), spec=0.35, ifc_mat='С2 Плитка фартука «звезда-крест» 250×250')
    # ткань стульев — велюр серо-графитовый
    tm('VELVET', 'Велюр серый (стулья)', 'velvet.jpg', M.tileable(T.fabric(240, 240, 0.25, (122, 116, 114), 3), 80, 80),
       (220, 220), spec=0.25)
    M.mat('GRAPHITE', 'ЭУИ белые матовые (по кадру)', (0.94, 0.94, 0.93), refl='PLASTIC', spec=0.3)
    M.mat('BRASS_POL', 'Латунь полированная (каркасы, ручки, светильники)', (0.83, 0.66, 0.36), refl='METAL', spec=0.85)
    M.mat('SPHERE', 'Керамика глазурованная серая (шар опоры стола)', (0.56, 0.53, 0.51), refl='PLASTIC', spec=0.85)
    M.mat('RAD', 'Сталь окрашенная, графит (радиатор)', (0.33, 0.33, 0.34), refl='METAL', spec=0.35)
    M.mat('FROST', 'Стекло матовое (сатинато)', (0.90, 0.92, 0.93), transp=0.35, refl='GLASS', spec=0.5)
    M.mat('ALU_BLACK', 'Алюминий чёрный матовый (профиль перегородки)', (0.10, 0.10, 0.11), refl='METAL', spec=0.3)
    M.mat('CHROME', 'Хром (ручка двери)', (0.82, 0.83, 0.84), refl='METAL', spec=0.9)
    M.mat('KETTLE', 'Сталь эмаль графит-металлик (чайник)', (0.40, 0.41, 0.43), refl='METAL', spec=0.7)
    M.mat('COPPER_POL', 'Медь полированная (сковорода, декор)', (0.86, 0.56, 0.30), refl='METAL', spec=0.85)
    M.mat('ENAMEL_W', 'Эмаль белая (кастрюля, банки)', (0.95, 0.95, 0.94), refl='PLASTIC', spec=0.5)
    M.mat('FLOWER', 'Гортензия кремовая (декор)', (0.94, 0.94, 0.88), refl='MATT', spec=0.05)
    M.mat('LEAF', 'Зелень (декор)', (0.36, 0.45, 0.27), refl='MATT', spec=0.1)
    M.mat('CAKE', 'Выпечка (декор стола)', (0.45, 0.27, 0.16), refl='MATT', spec=0.1)
    M.mat('TURQ', 'Керамика бирюзовая (декор ниши)', (0.25, 0.66, 0.66), refl='PLASTIC', spec=0.5)
    M.mat('FRAME_BLK', 'Картина / фото, чёрная графика', (0.12, 0.12, 0.13), refl='MATT', spec=0.1)
    M.mat('GLASS_VASE', 'Стекло дымчатое (ваза)', (0.70, 0.66, 0.55), transp=0.4, refl='GLASS', spec=0.8)
    M.mat('CAST', 'Чугун (решётки варочной панели)', (0.08, 0.08, 0.08), refl='METAL', spec=0.25)
    # столешница стола: светлый камень/шпон (по кадру — светло-серый бежевый)
    T.COL['marble'] = (206, 199, 191)
    tm('TABLETOP', 'Столешница стола — камень светлый серо-бежевый', 'table_top.jpg', T.marble(1200, 1200, 1.0, 21,
       vein_col=(176, 168, 160)), (1200, 1200), spec=0.45, ifc_mat='Камень светлый (столешница стола)')
    # фарфор с синим узором (тарелки, чайник) — процедурный «кобальт»
    w = 256
    yy, xx = np.mgrid[0:w, 0:w] / w
    rr = np.hypot(xx - 0.5, yy - 0.5)
    pat = (np.sin(rr * 60) > 0.55) | ((np.sin(np.arctan2(yy - 0.5, xx - 0.5) * 12) > 0.6) & (rr > 0.28) & (rr < 0.42))
    por = np.where(pat[..., None], np.array([40, 70, 150], np.float32), np.array([246, 246, 244], np.float32))
    tm('PORC', 'Фарфор белый с кобальтовым узором', 'porcelain.jpg', por, (240, 240), spec=0.6)
    # пол: инженерная доска дуб светлый 180×1800, доски — вдоль оси кухни (к стене фартука)
    def planks_x(W, H, mpp, seed=0, bw=180, bl=1800):
        """Доски вдоль вертикали образца (= ось x модели, к стене кухни), волокна вдоль досок, швы тонкие."""
        w, h = T._grid_px(W, H, mpp)
        rg = np.random.default_rng(seed + 11)
        base = T.wood(h, w, (216, 201, 182), rg, mpp, 'v', fig=0.6)
        xs = np.arange(w) * mpp
        ys = (h - np.arange(h)) * mpp
        col = (xs // bw).astype(int)
        off = (col * 700) % bl
        row = ((ys[:, None] + off[None, :]) // bl).astype(int)
        bid = col[None, :] * 131 + row * 7
        hs = np.sin(bid * 12.9898 + 4.1) * 43758.5453
        tv = ((hs - np.floor(hs)) - 0.5) * 14
        fx = np.minimum(xs % bw, bw - xs % bw)
        fy = np.minimum((ys[:, None] + off[None, :]) % bl, bl - (ys[:, None] + off[None, :]) % bl)
        seam = np.exp(-(fx[None, :] / 1.3) ** 2) * 38 + np.exp(-(fy / 1.3) ** 2) * 32
        return base + (tv - seam)[..., None]
    T.planks_tex = planks_x


# ================================================================ локальная система у стены
class Fr:
    """u — от стены в помещение, w — вдоль стены, z — вверх."""
    def __init__(s, o, eu, ew):
        s.o = V(o, float); s.eu = V(eu, float); s.ew = V(ew, float); s.ez = V((0, 0, 1.0))

    def P(s, u, w, z):
        return s.o + s.eu * u + s.ew * w + s.ez * z

    def rb(s, el, m, u0, u1, w0, w1, z0, z1, r=1.5, seg=2):
        c = s.P((u0 + u1) / 2, (w0 + w1) / 2, (z0 + z1) / 2)
        H.rbox_f(el, m, c, s.eu, s.ew, s.ez, abs(u1 - u0) / 2, abs(w1 - w0) / 2, abs(z1 - z0) / 2, r, seg)

    def bx(s, el, m, u0, u1, w0, w1, z0, z1):
        a, b = s.P(u0, w0, z0), s.P(u1, w1, z1)
        box(el, m, min(a[0], b[0]), min(a[1], b[1]), min(a[2], b[2]), max(a[0], b[0]), max(a[1], b[1]), max(a[2], b[2]))

    def frame(s):
        """для колец/тел вращения с осью по eu: (ex, ey, ez) = (ew, ez, eu)"""
        return (s.ew, s.ez, s.eu)


FB = Fr((0, 0, 0), (1, 0, 0), (0, 1, 0))          # стена кухни (фартук), w = y
FL = Fr((0, 0, 0), (0, 1, 0), (1, 0, 0))          # левая стена, w = x
FR_ = Fr((0, 3300, 0), (0, -1, 0), (1, 0, 0))     # правая стена, w = x


# ================================================================ фасады и фурнитура
def shaker(F, el, uf, w0, w1, z0, z1, m='FRONT', rail=72, glass=False, lattice=False):
    """Фасад «шейкер»: рамка (стойки/перемычки) + утопленная филёнка; uf — плоскость лица фасада."""
    t, rec = FRONT_T, 7
    w0, w1, z0, z1 = w0 + GAP, w1 - GAP, z0 + GAP, z1 - GAP
    rail = min(rail, (w1 - w0) / 3.2, (z1 - z0) / 3.2)
    if not glass:
        F.rb(el, m, uf - t, uf - rec, w0, w1, z0, z1, 1.5)           # филёнка
    for a, b, c, d in ((w0, w0 + rail, z0, z1), (w1 - rail, w1, z0, z1),
                       (w0 + rail, w1 - rail, z0, z0 + rail), (w0 + rail, w1 - rail, z1 - rail, z1)):
        F.rb(el, m, uf - t, uf, a, b, c, d, 2.0, 2)
    # фаска-калёвка по внутреннему контуру рамки (протяжка треугольного профиля)
    pts = [F.P(uf - rec, w0 + rail, z0 + rail), F.P(uf - rec, w1 - rail, z0 + rail),
           F.P(uf - rec, w1 - rail, z1 - rail), F.P(uf - rec, w0 + rail, z1 - rail)]
    H.sweep_up(el, m, pts, [(0, 0), (-5, 0), (0, rec - 0.5)], F.eu, closed_path=True, caps=False)
    if glass:
        F.rb(el, 'GLASS', uf - t / 2 - 2, uf - t / 2 + 2, w0 + rail - 8, w1 - rail + 8, z0 + rail - 8, z1 - rail + 8, 0.5, 1)
        if lattice:
            gw0, gw1, gz0, gz1 = w0 + rail, w1 - rail, z0 + rail, z1 - rail
            wc = (gw0 + gw1) / 2
            bw = 13
            R = (gw1 - gw0) * 0.34
            F.rb(el, m, uf - 9, uf - 2, wc - bw / 2, wc + bw / 2, gz0, gz1, 1.0, 1)
            for fz in (0.80, 0.49, 0.21):
                zc = gz0 + (gz1 - gz0) * fz
                for a, b in ((gw0, wc - R + 4), (wc + R - 4, gw1)):
                    F.rb(el, m, uf - 9, uf - 2, a, b, zc - bw / 2, zc + bw / 2, 1.0, 1)
                c = F.P(0, wc, zc)
                H.ring(el, m, c, R - bw, R, uf - 9, uf - 2, 64, frame=F.frame())


def cup_pull(F, el, uf, wc, zc, L=100):
    """Ручка-ракушка (латунь): основание + полуоболочка, открытая вниз."""
    m = 'BRASS_POL'
    F.rb(el, m, uf, uf + 3, wc - L / 2 - 5, wc + L / 2 + 5, zc - 8, zc + 20, 1.5, 2)
    G = []
    for i in range(15):
        ph = math.radians(150.0 * i / 14)
        row = []
        for j in range(21):
            t = -1 + 2 * j / 20
            k = (max(0.0, 1 - abs(t) ** 4)) ** 0.5
            R = 18 * k + 0.4
            row.append(F.P(uf + 3 + R * math.sin(ph), wc + t * L / 2, zc + 2 + R * math.cos(ph)))
        G.append(row)
    H.add_grid(el, m, G, orient='auto', center=F.P(uf - 10, wc, zc - 5))


def knob(F, el, uf, wc, zc):
    prof = [(0.01, 0), (7, 0), (6, 8), (5, 14), (10, 19), (13, 24), (12.5, 28), (8, 31), (0.01, 32)]
    H.lathe(el, 'BRASS_POL', prof, F.P(uf, wc, zc), 32, frame=F.frame())


# ================================================================ кухня
def _worktop(F, el, u0, u1, w0, w1, holes=()):
    """Столешница орех 40 мм, со скруглённой кромкой; holes — вырезы [(u0,u1,w0,w1)] (мойка)."""
    if not holes:
        F.rb(el, 'WALNUT', u0, u1, w0, w1, TOP - 40, TOP, 3, 3)
        return
    hu0, hu1, hw0, hw1 = holes[0]
    F.rb(el, 'WALNUT', u0, u1, w0, hw0, TOP - 40, TOP, 3, 3)
    F.rb(el, 'WALNUT', u0, u1, hw1, w1, TOP - 40, TOP, 3, 3)
    F.bx(el, 'WALNUT', u0, hu0, hw0 - 2, hw1 + 2, TOP - 40, TOP)
    F.rb(el, 'WALNUT', hu1, u1, hw0 - 2, hw1 + 2, TOP - 40, TOP, 3, 3)


def k_base_left(el, it, r, z, room, zf):
    """Нижние модули у левой стены (Г-образная кухня): фасады к столовой (+y), торцевая панель к камере (+x)."""
    F = FL
    F.bx(el, 'FRONT', 0, 540, 30, 1480, 0, 100)                            # цоколь (утоплен)
    F.bx(el, 'FRONT', 0, 600 - FRONT_T, 0, 1500, 100, TOP - 40)            # корпус
    # фасады: два ящика 900 (x 600…1500)
    shaker(F, el, 600, 600, 1500, 103, 517)
    shaker(F, el, 600, 600, 1500, 520, TOP - 43)
    cup_pull(F, el, 600, 1050, TOP - 95)
    knob(F, el, 600, 1050, 470)
    # торцевая панель «шейкер» к столовой
    shaker(FB, el, 1520, 0, 620, 0, TOP - 41, rail=80)
    _worktop(FB, el, 0, 1535, 0, 620)
    el.props['Фасады'] = 'МДФ «шейкер», эмаль матовая NCS S 4040-R80B; ручки-ракушки и кнопки — латунь'
    el.props['Столешница'] = 'Массив ореха 40 мм, масло'


def k_base_back(el, it, r, z, room, zf):
    F = FB
    F.bx(el, 'FRONT', 0, 540, 600, 2850, 0, 100)
    F.bx(el, 'FRONT', 0, 600 - FRONT_T, 600, 2850, 100, TOP - 40)
    sink = None
    for a, b, kind in it['modules']:
        wc = (a + b) / 2
        if kind == 'filler':
            shaker(F, el, 600, a, b, 103, TOP - 43, rail=45)
        elif kind == 'sink':
            shaker(F, el, 600, a, b, 103, TOP - 43)
            cup_pull(F, el, 600, wc, TOP - 95)
            sink = (wc, b - a)
        else:
            shaker(F, el, 600, a, b, 520, TOP - 43)
            shaker(F, el, 600, a, b, 103, 517)
            cup_pull(F, el, 600, wc, TOP - 95)
            knob(F, el, 600, wc, 470)
    wc, wd = sink
    sw, su0, su1 = 340, 110, 470
    _worktop(F, el, 0, 620, 620, 2850, holes=[(su0, su1, wc - sw / 2, wc + sw / 2)])
    # мойка подстольная, сталь сатин
    w0, w1 = wc - sw / 2, wc + sw / 2
    zb = TOP - 40 - 190
    F.bx(el, 'STEEL', su0, su1, w0, w1, zb, zb + 2)
    for (a, b, c, d) in ((su0, su0 + 1.5, w0, w1), (su1 - 1.5, su1, w0, w1), (su0, su1, w0, w0 + 1.5), (su0, su1, w1 - 1.5, w1)):
        F.bx(el, 'STEEL', a, b, c, d, zb, TOP - 40)
    H.lathe(el, 'STEEL', [(0.01, zb + 2.5), (22, zb + 2.5), (22, zb + 5), (0.01, zb + 5)], F.P(290, wc, 0), 24)
    # смеситель латунь: однорычажный с поворотным изливом-«пантографом» (по кадру)
    m = 'BRASS_POL'
    bu, bw_ = 55, wc - 60
    H.lathe(el, m, [(0.01, TOP), (24, TOP), (24, TOP + 6), (17, TOP + 12), (16, TOP + 150), (13, TOP + 160), (0.01, TOP + 162)],
            F.P(bu, bw_, 0), 32)
    H.cone(el, m, F.P(bu, bw_ + 8, TOP + 120), F.P(bu, bw_ + 45, TOP + 125), 6, 6, 16)        # рычаг
    H.pipe(el, m, [F.P(bu, bw_, TOP + 155), F.P(bu, bw_, TOP + 245), F.P(bu + 150, bw_ + 40, TOP + 245)], 9, bend=40, n=20)
    H.sphere(el, m, F.P(bu + 150, bw_ + 40, TOP + 245), 13, 20)
    H.pipe(el, m, [F.P(bu + 150, bw_ + 40, TOP + 245), F.P(bu + 280, wc + 30, TOP + 245), F.P(bu + 280, wc + 30, TOP + 200)],
           8, bend=30, n=20)
    # варочная панель (газ, чёрное стекло, чугунные решётки) над модулем 750
    hob = (it['hob'][0] + it['hob'][1]) / 2 if it.get('hob') else None
    if hob:
        hw, hu0, hu1 = 580, 50, 560
        F.rb(el, 'BLACKGLASS', hu0, hu1, hob - hw / 2, hob + hw / 2, TOP, TOP + 6, 2, 2)
        for du, dw, rr in ((170, -150, 50), (170, 150, 38), (390, -150, 38), (390, 150, 58)):
            c = F.P(du, hob + dw, 0)
            H.lathe(el, 'CAST', [(0.01, TOP + 6), (rr + 14, TOP + 6), (rr + 12, TOP + 14), (0.01, TOP + 16)], c, 32)
            H.lathe(el, 'BRASS', [(0.01, TOP + 16), (rr * 0.55, TOP + 16), (rr * 0.5, TOP + 22), (0.01, TOP + 23)], c, 32)
        for uu in (hu0 + 20, (hu0 + hu1) / 2, hu1 - 20):
            F.rb(el, 'CAST', uu - 5, uu + 5, hob - hw / 2 + 15, hob + hw / 2 - 15, TOP + 6, TOP + 30, 2, 1)
        for ww in (hob - hw / 2 + 15, hob, hob + hw / 2 - 15):
            F.rb(el, 'CAST', hu0 + 15, hu1 - 15, ww - 5, ww + 5, TOP + 6, TOP + 30, 2, 1)
        for i, dw in enumerate((-200, -120, 120, 200)):             # ручки конфорок на лицевой кромке
            H.lathe(el, 'STEEL', [(0.01, 0), (17, 0), (17, 20), (12, 26), (0.01, 26)], F.P(hu1 - 20, hob + dw, TOP + 6), 24)
    el.props['Мойка'] = 'подстольная сталь 340×360, смеситель латунь'
    el.props['Варочная панель'] = 'газовая 4 конфорки, чёрное стекло (по кадру — уточнить)'


def _cornice(F, el, u_face, w0, w1, z0, ret0=False, ret1=False):
    """Карниз: полка-фриз + выкружка + верхняя полка; ret — заворот на торец."""
    m = 'FRONT'
    F.rb(el, m, 0, u_face + 6, w0, w1, z0, z0 + 40, 1.5, 2)
    # выкружка: протяжка четверти круга по лицу
    prof = [(0, 0)] + [(-(26 - 26 * math.cos(math.radians(a))), 26 * math.sin(math.radians(a))) for a in range(0, 91, 10)] + [(0, 26)]
    prof = [(p[0], p[1]) for p in prof]
    pts = [F.P(u_face + 6, w1, z0 + 40), F.P(u_face + 6, w0, z0 + 40)]
    H.sweep_up(el, m, pts, [(-u, v) for u, v in prof], F.ez, closed_path=False, caps=True)
    F.rb(el, m, 0, u_face + 34, w0 - (28 if ret0 else 0), w1 + (28 if ret1 else 0), z0 + 66, z0 + 82, 2.5, 2)
    F.rb(el, m, 0, u_face + 22, w0, w1, z0 + 82, UP1, 1.5, 2)


def _porcelain_shelf(el, F, w0, w1, zs, u_back):
    """Посуда в витрине: тарелки на ребре, банки с крышками, чашки."""
    wc = (w0 + w1) / 2
    k = int((zs * 7) % 3)
    if k == 0:
        H.lathe(el, 'PORC', [(0.01, -6), (120, -6), (125, 0), (118, 2), (0.01, 4)], F.P(u_back + 40, wc - 20, zs + 128), 48,
                frame=(F.ew, F.ez, F.eu * 0.966 + F.ez * 0.259))
        H.lathe(el, 'PORC', [(0.01, 0), (40, 0), (46, 70), (44, 75), (0.01, 72)], F.P(u_back + 170, wc + 70, zs), 32)
    elif k == 1:
        for dw in (-55, 55):
            c = F.P(u_back + 120, wc + dw, zs)
            H.lathe(el, 'ENAMEL_W', [(0.01, 0), (48, 0), (50, 4), (50, 150), (45, 156), (0.01, 156)], c, 40)
            H.lathe(el, 'PORC', [(0.01, 156), (52, 156), (52, 168), (30, 178), (14, 185), (14, 195), (0.01, 197)], c, 40)
    else:
        for dw in (-50, 50):
            for zz in (0, 62):
                c = F.P(u_back + 140, wc + dw, zs + zz)
                H.lathe(el, 'ENAMEL_W', [(0.01, 0), (26, 0), (36, 30), (42, 60), (40, 60), (0.01, 4)], c, 32)
        H.lathe(el, 'PORC', [(0.01, -6), (105, -6), (110, 0), (104, 2), (0.01, 4)], F.P(u_back + 30, wc, zs + 112), 48,
                frame=(F.ew, F.ez, F.eu * 0.966 + F.ez * 0.259))


def k_upper(el, it, r, z, room, zf):
    F = FB
    mods = [(0, 630, 'door'), (630, 1240, 'door'), (1240, 1650, 'glass'), (1650, 2400, 'hood'), (2400, 2850, 'glass')]
    zt = 2860                    # верх фасадов (под карнизом)
    for a, b, kind in mods:
        dep = 400 if kind == 'hood' else 350
        uf = dep
        wc = (a + b) / 2
        if kind == 'door':
            F.bx(el, 'FRONT', 0, uf - FRONT_T, a, b, UP0, zt)
            shaker(F, el, uf, a, b, UP0, zt)
            knob(F, el, uf, b - 45 if a == 0 else a + 45, UP0 + 60)
        elif kind == 'glass':
            # корпус: боковины, дно, верх, задник светлый, полки, подсветка
            F.bx(el, 'FRONT', 0, uf - FRONT_T, a, a + 18, UP0, zt)
            F.bx(el, 'FRONT', 0, uf - FRONT_T, b - 18, b, UP0, zt)
            F.bx(el, 'FRONT', 0, uf - FRONT_T, a, b, UP0, UP0 + 18)
            F.bx(el, 'FRONT', 0, uf - FRONT_T, a, b, zt - 18, zt)
            F.bx(el, 'ENAMEL_W', 0, 8, a + 18, b - 18, UP0 + 18, zt - 18)
            for zs in (UP0 + 18 + 400, UP0 + 18 + 800):
                F.bx(el, 'WHITE', 8, uf - FRONT_T - 4, a + 18, b - 18, zs - 18, zs)
            F.bx(el, 'LED', uf - FRONT_T - 50, uf - FRONT_T - 30, a + 30, b - 30, zt - 20, zt - 18)
            for zs in (UP0 + 18, UP0 + 418, UP0 + 818):
                _porcelain_shelf(el, F, a + 18, b - 18, zs, 8)
            shaker(F, el, uf, a, b, UP0, zt, glass=True, lattice=True, rail=60)
            knob(F, el, uf, a + 40 if a == 2400 else b - 40, UP0 + 55)
        else:  # шкаф-вытяжка: дверь + козырёк, встроенный блок вытяжки
            F.bx(el, 'FRONT', 0, uf - FRONT_T, a, b, UP0 + 140, zt)
            shaker(F, el, uf, a, b, UP0 + 145, zt)
            F.rb(el, 'FRONT', 0, uf + 12, a + 1, b - 1, UP0, UP0 + 140, 3, 2)          # козырёк
            F.rb(el, 'FRONT', uf + 2, uf + 14, a + 6, b - 6, UP0 + 10, UP0 + 130, 2, 2)
            F.bx(el, 'STEEL', 40, uf - 30, a + 60, b - 60, UP0 - 3, UP0)                 # встроенная вытяжка
            for i in range(3):
                F.bx(el, 'BLACK', 60 + i * 100, 140 + i * 100, a + 80, b - 80, UP0 - 4, UP0 - 3)
        _cornice(F, el, uf, a, b, zt, ret0=(a == 0), ret1=(b == 2850))
    el.props['Фасады'] = 'шейкер, эмаль NCS S 4040-R80B; витрины — стекло с переплётом «кольца»'
    el.props['Подсветка'] = 'светодиодная под шкафами + в витринах'


def k_column(el, it, r, z, room, zf):
    F = FB
    a, b = 2850, 3300
    F.bx(el, 'FRONT', 0, 540, a, b, 0, 100)
    F.bx(el, 'FRONT', 0, 600 - FRONT_T, a, b, 100, 2860)
    shaker(F, el, 600, a, b, 103, 900)
    shaker(F, el, 600, a, b, 903, 2860)
    knob(F, el, 600, a + 45, 950)
    knob(F, el, 600, a + 45, 855)
    _cornice(F, el, 600, a, b, 2860, ret0=True)
    el.props['Встроенная техника'] = 'холодильник с морозильной камерой (по кадру — две двери; уточнить)'


# ================================================================ стол и стулья
def _facet_lathe(el, m, prof, c, n=8, a0=0.0):
    """Гранёное тело вращения (n граней, плоские грани)."""
    G = []
    for rr, hh in prof:
        G.append([(c[0] + rr * math.cos(a0 + 2 * math.pi * i / n), c[1] + rr * math.sin(a0 + 2 * math.pi * i / n), c[2] + hh)
                  for i in range(n)])
    H.add_grid(el, m, G, closed_u=True, orient='auto', center=(c[0], c[1], c[2] + sum(h for _, h in prof) / len(prof)), sharp=True)
    for rr, hh, sg in ((prof[0][0], prof[0][1], -1), (prof[-1][0], prof[-1][1], 1)):
        if rr > 0.01:
            H.cap(el, m, G[0] if sg < 0 else G[-1], normal=(0, 0, sg))


def table_ped(el, it, r, z, room, zf):
    cx, cy = it['c']
    R = it['r']
    zt = z[1]
    c0 = (cx, cy, 0)
    # столешница: камень светлый на подстолье из ореха
    H.lathe(el, 'WALNUT', [(0.01, zt - 48), (R - 30, zt - 48), (R - 6, zt - 42), (R, zt - 32), (R, zt - 18), (0.01, zt - 18)], c0, 128,
            uv='planar')
    H.lathe(el, 'TABLETOP', [(0.01, zt - 18), (R - 2, zt - 18), (R, zt - 14), (R, zt - 3), (R - 3, zt), (0.01, zt)], c0, 128,
            uv='planar')
    H.lathe(el, 'WALNUT', [(0.01, zt - 70), (170, zt - 70), (175, zt - 60), (175, zt - 48), (0.01, zt - 48)], c0, 48)
    # опора: брус-шейка (орех), латунное кольцо, шар-керамика, кольцо, гранёный «кристалл», кольцо, гранёный конус, основание
    H.rbox(el, 'WALNUT', cx - 66, cy - 66, 520, cx + 66, cy + 66, zt - 70, 4, 3)
    H.lathe(el, 'BRASS_POL', [(0.01, 505), (64, 505), (64, 522), (0.01, 522)], c0, 48)
    H.sphere(el, 'SPHERE', (cx, cy, 390), 125, 64)
    H.lathe(el, 'BRASS_POL', [(0.01, 262), (54, 262), (54, 278), (0.01, 278)], c0, 48)
    _facet_lathe(el, 'WALNUT', [(30, 120), (96, 195), (40, 262)], c0, 8, math.radians(22.5))
    H.lathe(el, 'BRASS_POL', [(0.01, 106), (40, 106), (40, 120), (0.01, 120)], c0, 48)
    _facet_lathe(el, 'WALNUT', [(150, 40), (36, 106)], c0, 8, math.radians(22.5))
    H.lathe(el, 'WALNUT', [(0.01, 0), (330, 0), (338, 8), (335, 22), (310, 36), (240, 46), (150, 50), (0.01, 50)], c0, 96,
            uv='planar')
    el.props['Материалы'] = 'столешница камень светлый на орехе; опора орех, латунь, керамика глазурь'


def chair_brass(el, it, r, z, room, zf):
    c = it['c']; ang = it['ang']
    a = math.radians(ang)
    ex = V((math.cos(a), math.sin(a), 0.0)); ey = V((-math.sin(a), math.cos(a), 0.0)); C = V((c[0], c[1], 0.0))

    def P(u, v, h):
        return C + ex * u + ey * v + V((0, 0, h))
    m, fab = 'BRASS_POL', 'VELVET'
    hu, hv, za = 200, 228, 640
    rt = 8
    # каркас: передние стойки → подлокотник → обвязка спинки → подлокотник → передняя стойка
    H.pipe(el, m, [P(hu, -hv, 0), P(hu, -hv, za), P(-hu + 20, -hv, za), P(-hu + 20, hv, za), P(hu, hv, za), P(hu, hv, 0)],
           rt, bend=55, n=16)
    for v in (-hv, hv):
        H.pipe(el, m, [P(-hu + 20, v, 0), P(-hu + 20, v, za)], rt, n=16)
        H.lathe(el, m, [(0.01, 0), (rt + 1, 0), (rt + 1, 4), (0.01, 4)], P(hu, v, 0), 16)
        H.lathe(el, m, [(0.01, 0), (rt + 1, 0), (rt + 1, 4), (0.01, 4)], P(-hu + 20, v, 0), 16)
    # рама сиденья
    H.pipe(el, m, [P(hu, -hv, 420), P(-hu + 20, -hv, 420), P(-hu + 20, hv, 420), P(hu, hv, 420), P(hu, -hv, 420)], 7, bend=40, n=14)
    # сиденье: мягкая подушка, скруглённая
    H.rbox_f(el, fab, P(5, 0, 460), ex, ey, (0, 0, 1), 222, 244, 34, 28, 6)
    # спинка-«бочка»: дуга вокруг задней части, сечение — скруглённый прямоугольник
    path = [P(-10 + 228 * math.cos(math.radians(t)), 244 * math.sin(math.radians(t)), 735) for t in np.linspace(62, 298, 40)]
    prof = [(p[0], p[1]) for p in H.superellipse(0, 0, 36, 92, e=5, n=40)]
    H.sweep_pt(el, fab, path, prof, closed_prof=True, caps=True)
    for t in (62, 298):          # скруглённые торцы спинки
        tt = math.radians(t)
        H.sphere(el, fab, P(-10 + 228 * math.cos(tt), 244 * math.sin(tt), 735), 36, 24, sz=2.5)
    el.props['Материалы'] = 'каркас — латунь полированная, сиденье и спинка — велюр серый'


# ================================================================ стены: ТВ, полка, ниша, радиатор
def tv_wall(el, it, r, z, room, zf):
    x0, y0, x1, y1 = r
    F = FL
    F.rb(el, 'BLACK', 10, 26, x0 + 300, x1 - 300, z[0] + 150, z[1] - 150, 3, 2)            # кронштейн
    F.rb(el, 'BLACK', 26, 45, x0, x1, z[0], z[1], 3, 3)                                  # корпус
    F.bx(el, 'SCREEN', 45, 45.6, x0 + 6, x1 - 6, z[0] + 6, z[1] - 6)
    el.name = 'Телевизор 58" настенный (кронштейн)'


def wall_shelf(el, it, r, z, room, zf):
    x0, y0, x1, y1 = r
    rng = np.random.default_rng(5)
    xs = np.linspace(x0, x1, 40)
    edge = y1 - 25 + np.cumsum(rng.normal(0, 4, len(xs))).clip(-20, 20)
    poly = [(x0, y0)] + [(float(x), float(e)) for x, e in zip(xs, edge)] + [(x1, y0)]
    poly = [(x0, 0)] + [(float(x), float(e)) for x, e in zip(xs, edge)][::1] + [(x1, 0)]
    prism(el, 'WALNUT', poly, z[0], z[1])
    m = 'BRASS_POL'
    for xb in (x0 + 260, x1 - 300):                     # кронштейны-треугольники из латунного прутка
        H.pipe(el, m, [(xb, 2, z[0] - 1), (xb, 190, z[0] - 1), (xb, 2, z[0] - 210), (xb, 2, z[0] - 1)], 4, bend=6, n=10)
        H.pipe(el, m, [(xb, 100, z[0] - 1), (xb, 40, z[0] - 150)], 3.5, n=10)
    # декор на полке: латунная восьмигранная рамка, два подсвечника
    H.ring(el, m, (x1 - 120, 110, z[1] + 120), 95, 112, -6, 6, 8, frame=((1, 0, 0), (0, 0, 1), (0, 1, 0)))
    for (xc, hgt) in ((x0 + 120, 330), (x0 + 200, 250)):
        c = (xc, 120, z[1])
        H.lathe(el, m, [(0.01, 0), (40, 0), (40, 6), (12, 14), (9, hgt - 30), (22, hgt - 22), (22, hgt - 16), (12, hgt - 14),
                        (12, hgt), (0.01, hgt)], c, 32)
        H.lathe(el, 'ENAMEL_W', [(0.01, hgt), (11, hgt), (11, hgt + 60), (0.01, hgt + 62)], c, 24)


def niche_shelving(el, it, r, z, room, zf):
    x0, y0, x1, y1 = r                   # 835…1530 × 3300…3600
    from ifc.scene3d import mkey
    pl = mkey('С1')
    box(el, pl, x0, y0, z[1], x1, y1, 3000)                       # перемычка над нишей (откосы — штукатурка)
    for zt in (1040, 1500, 1960):                                  # полки белые 30 мм
        H.rbox(el, 'WHITE', x0, y0 + 25, zt - 30, x1, y1, zt, 2, 2)
    for xc in (955, 1435):                                         # стойки орех 50×50 от пола до перемычки
        H.rbox(el, 'WALNUT', xc - 25, y0 - 10, 0, xc + 25, y0 + 40, z[1], 3, 2)
    # декор: рамка с графикой, латунный кувшин, бирюзовая тарелка, стакан с кистями
    H.rbox(el, 'BRASS_POL', 1000, 3480, 1960, 1260, 3500, 2200, 3, 2)
    box(el, 'FRAME_BLK', 1020, 3478, 1980, 1240, 3480, 2180)
    H.lathe(el, 'BRASS_POL', [(0.01, 0), (55, 0), (58, 10), (70, 70), (62, 130), (34, 180), (30, 230), (46, 250), (0.01, 252)],
            (1200, 3470, 1500), 40)
    H.lathe(el, 'TURQ', [(0.01, -5), (140, -5), (145, 0), (138, 3), (0.01, 6)], (1330, 3560, 1040 + 140), 48,
            frame=((1, 0, 0), (0, 0.26, 0.966), (0, -0.966, 0.26)))
    H.lathe(el, 'PORC', [(0.01, 0), (45, 0), (48, 110), (0.01, 110)], (1250, 3440, 1040), 32)
    for i, dx in enumerate((-15, 0, 18)):
        H.pipe(el, 'BRASS_POL', [(1250 + dx, 3440 + 8 * i - 8, 1060), (1250 + dx * 2.2, 3440 + 12 * i - 12, 1230)], 4, n=8)
    el.props['Состав'] = 'ниша 695×300×2600, полки ЛДСП белая 30 мм, стойки массив ореха 50×50, подсветка'


def radiator_tube(el, it, r, z, room, zf):
    x0, y0, x1, y1 = r
    yc = (y0 + y1) / 2
    n = 9
    for i in range(n):
        xc = x0 + 25 + i * (x1 - x0 - 50) / (n - 1)
        H.lathe(el, 'RAD', [(0.01, z[0]), (22, z[0]), (22, z[1]), (0.01, z[1])], (xc, yc, 0), 24)
    for zz in (z[0] + 40, z[1] - 40):
        H.rbox(el, 'RAD', x0 + 5, yc - 15, zz - 25, x1 - 5, yc + 15, zz + 25, 6, 2)
    for zz in (z[0] + 300, z[1] - 300):                           # кронштейны
        H.rbox(el, 'RAD', (x0 + x1) / 2 - 15, yc + 10, zz - 10, (x0 + x1) / 2 + 15, y1, zz + 10, 2, 1)


# ================================================================ светильники
def track_brass(el, L, zc):
    (xa, ya), (xb, yb) = L['a'], L['b']
    F = FB
    F.rb(el, 'BLACK', xa - 18, xa + 18, ya + 15, yb - 15, zc - 45, zc, 2, 2)
    for yy in L.get('spots', []):
        F.rb(el, 'BLACK', xa - 16, xa + 16, yy - 25, yy + 25, zc - 62, zc - 45, 2, 1)
        H.cone(el, 'BRASS_POL', (xa, yy, zc - 62), (xa, yy, zc - 105), 7, 7, 12)
        H.sphere(el, 'BRASS_POL', (xa, yy, zc - 108), 13, 16)
        # корпус спота наклонён к кухне (−x) на 35°
        d = V((-math.sin(math.radians(35)), 0, -math.cos(math.radians(35))))
        p0 = V((xa, yy, zc - 108)) - d * 55
        p1 = V((xa, yy, zc - 108)) + d * 75
        H.cone(el, 'BRASS_POL', tuple(p0), tuple(p1), 30, 30, 32)
        H.cone(el, 'BLACK', tuple(p1), tuple(p1 + d * 1.5), 26, 26, 24)
        H.cone(el, 'LED', tuple(p1 + d * 1.5), tuple(p1 + d * 2), 16, 16, 16)
    el.name = 'Магнитный трек накладной черный + 3 спота латунь (01а)'


def chandelier_molecule(el, L, zc):
    x, y = L['p']
    zh = L.get('z', 2000)
    m = 'BRASS_POL'
    H.lathe(el, m, [(0.01, zc - 22), (62, zc - 22), (62, zc - 4), (55, zc), (0.01, zc)], (x, y, 0), 48)
    H.cone(el, m, (x, y, zc - 22), (x, y, zh + 18), 6, 6, 16)
    H.lathe(el, m, [(0.01, zh - 16), (40, zh - 16), (44, zh - 8), (44, zh + 8), (40, zh + 16), (0.01, zh + 16)], (x, y, 0), 40)
    arms = [(100, 3, 380), (35, -5, 320), (160, 6, 350)]        # азимут, наклон, полудлина
    for az, el_, Lh in arms:
        d = V((math.cos(math.radians(az)) * math.cos(math.radians(el_)), math.sin(math.radians(az)) * math.cos(math.radians(el_)),
               math.sin(math.radians(el_))))
        c = V((x, y, zh))
        for sg in (-1, 1):
            p_end = c + d * Lh * sg
            H.cone(el, m, tuple(c), tuple(p_end), 6.5, 6.5, 16)
            # «узел» с отводом: втулка на середине плеча
            mid = c + d * Lh * 0.62 * sg
            H.lathe(el, m, [(0.01, -14), (11, -14), (11, 14), (0.01, 14)], tuple(mid), 20, frame=H.axis_frame(d * sg))
            # патрон и лампа G125 (опал), отвод под углом вверх/вниз
            dd = d * sg * 0.97 + V((0, 0, 0.16))
            dd = dd / np.linalg.norm(dd)
            s0 = p_end
            s1 = p_end + dd * 70
            H.cone(el, m, tuple(s0), tuple(s1), 19, 21, 24)
            H.sphere(el, 'OPAL', tuple(s1 + dd * 60), 62, 40)
    el.name = 'Люстра «молекула» 6 ламп G125, латунь (01б)'


def niche_spot(el, L, zc):
    x, y = L['p']
    z = L['z']
    H.lathe(el, 'BRASS_POL', [(0.01, z - 12), (30, z - 12), (32, z - 4), (32, z), (0.01, z)], (x, y, 0), 32)
    H.lathe(el, 'LED', [(0.01, z - 13), (18, z - 13), (18, z - 12), (0.01, z - 12)], (x, y, 0), 24)
    el.name = 'Светильник мебельный накладной (01г)'


# ================================================================ доп. элементы сцены: перегородка, декор
def _decor(S, name, room='01'):
    el = Elem('IfcFurniture', name, room=room, predefined='USERDEFINED', objtype='Декор',
              props={'Помещение': room, 'Назначение': 'декор по визуализации'})
    return el


def build(S):
    # стеклянная перегородка с дверью в проёме левой стены (x 1530…2730)
    el = Elem('IfcDoor', 'Перегородка стеклянная с распашной дверью, стекло матовое, профиль чёрный', room='01',
              predefined='DOOR', props={'Помещение': '01', 'Проём, мм': '1200×3000', 'Полотно, мм': '750×2400'})
    yz0, yz1 = -60, -20
    box(el, 'ALU_BLACK', 1530, yz0, 0, 2730, yz1, 25)
    box(el, 'ALU_BLACK', 1530, yz0, 2975, 2730, yz1, 3000)
    box(el, 'ALU_BLACK', 1530, yz0, 2400, 2730, yz1, 2430)
    for xa, xb in ((1530, 1560), (1965, 1995), (2700, 2730)):
        box(el, 'ALU_BLACK', xa, yz0, 0, xb, yz1, 3000)
    box(el, 'FROST', 1560, -44, 25, 1965, -36, 2975)
    box(el, 'FROST', 1995, -44, 25, 2700, -36, 2400)
    box(el, 'FROST', 1995, -44, 2430, 2700, -36, 2975)
    for sy in (-1, 1):                                             # ручка-рычаг хром с двух сторон
        yb = -20 if sy > 0 else -60
        H.lathe(el, 'CHROME', [(0.01, 0), (26, 0), (26, 10), (0.01, 12)], (2060, yb, 1050), 32,
                frame=((1, 0, 0), (0, 0, 1), (0, sy, 0)))
        H.pipe(el, 'CHROME', [(2060, yb + sy * 10, 1050), (2060, yb + sy * 55, 1050), (2190, yb + sy * 55, 1050)], 9, bend=20, n=16)
    S.add(el)

    # декор на кухне
    el = _decor(S, 'Декор кухни: чайник, банка, доска, сковорода, кастрюля')
    # чайник ретро (графит + латунь) на левой столешнице
    c = (1180, 240, TOP)
    H.lathe(el, 'BRASS_POL', [(0.01, 0), (78, 0), (84, 10), (84, 34), (76, 40), (0.01, 40)], c, 48)
    H.lathe(el, 'KETTLE', [(0.01, 40), (88, 40), (98, 80), (100, 120), (92, 175), (70, 215), (44, 232), (0.01, 236)], c, 64)
    H.lathe(el, 'BRASS_POL', [(0.01, 236), (30, 236), (12, 252), (9, 268), (0.01, 272)], c, 24)
    H.pipe(el, 'BRASS_POL', [(1180, 240 - 95, TOP + 90), (1180, 240 - 150, TOP + 160), (1180, 240 - 105, TOP + 240),
                             (1180, 240 - 45, TOP + 245)], 9, bend=40, n=14)
    H.pipe(el, 'KETTLE', [(1180, 240 + 85, TOP + 100), (1180, 240 + 150, TOP + 170), (1180, 240 + 170, TOP + 185)], 12, bend=60, n=14)
    # банка для хранения (белая, медный поясок) у угла
    c = (420, 250, TOP)
    H.lathe(el, 'ENAMEL_W', [(0.01, 0), (120, 0), (128, 10), (128, 120), (118, 128), (0.01, 128)], c, 64)
    H.lathe(el, 'COPPER_POL', [(0.01, 60), (129.5, 60), (129.5, 76), (0.01, 76)], c, 64)
    H.lathe(el, 'ENAMEL_W', [(0.01, 128), (110, 128), (110, 140), (60, 160), (20, 165), (0.01, 166)], c, 64)
    # разделочная доска (орех) у фартука
    pts = [(0, -115), (0, 115), (340, 115), (380, 70), (420, 40), (470, 30), (500, 0), (470, -30), (420, -40), (380, -70), (340, -115)]
    rb = []
    for zz, yy in pts:
        rb.append((yy, zz))
        G0 = [(50, 330 + yy, TOP + zz) for zz, yy in pts]
    G1 = [(68, 330 + yy, TOP + zz) for zz, yy in pts]
    H.add_grid(el, 'WALNUT', [G0 + [G0[0]], G1 + [G1[0]]], orient='auto')
    H.cap(el, 'WALNUT', G0, normal=(-1, 0, 0)); H.cap(el, 'WALNUT', G1, normal=(1, 0, 0))
    # сковорода медная, прислонена к фартуку
    fr = ((0, 1, 0), (0.17, 0, 0.985), (0.985, 0, -0.17))
    H.lathe(el, 'COPPER_POL', [(0.01, 0), (120, 0), (140, 10), (150, 45), (146, 47), (136, 12), (118, 4), (0.01, 4)],
            (130, 580, TOP + 150), 64, frame=fr)
    H.pipe(el, 'BRASS_POL', [(100, 580, TOP + 300), (60, 580, TOP + 520)], 9, n=12)
    # кастрюля белая на варочной
    c = (300, 2025, TOP + 30)
    H.lathe(el, 'ENAMEL_W', [(0.01, 0), (110, 0), (115, 8), (115, 120), (112, 124), (0.01, 124)], c, 64)
    H.lathe(el, 'STEEL', [(0.01, 124), (118, 124), (100, 140), (40, 150), (0.01, 151)], c, 48)
    H.sphere(el, 'COPPER_POL', (300, 2025, TOP + 30 + 160), 14, 16)
    for sy in (-1, 1):
        H.rbox(el, 'COPPER_POL', 295, 2025 + sy * 120, TOP + 120, 305, 2025 + sy * 145, TOP + 135, 3, 1)
    S.add(el)

    # декор стола: тарелки, пирог, чайник, поднос с чашками, ваза с гортензиями, пиалы
    el = _decor(S, 'Сервировка стола: поднос, чайник, чашки, тарелки, ваза с гортензиями')
    cx, cy, zt = 2000, 2045, 760
    for (dx, dy) in ((-270, -260), (-250, 300)):
        c = (cx + dx, cy + dy, zt)
        H.lathe(el, 'BRASS_POL', [(0.01, 0), (125, 0), (130, 6), (124, 7), (0.01, 4)], c, 48)
        H.lathe(el, 'PORC', [(0.01, 4), (105, 4), (112, 10), (106, 11), (0.01, 8)], c, 48)
        H.rbox(el, 'CAKE', c[0] - 50, c[1] - 75, zt + 11, c[0] + 50, c[1] + 75, zt + 70, 8, 2)
    # поднос
    H.rbox(el, 'ENAMEL_W', cx - 180, cy - 230, zt, cx + 120, cy + 230, zt + 12, 4, 2)
    for (dx, dy) in ((-180, -230), (-180, 230 - 12), (120 - 12, -230), (-180, -230)):
        pass
    H.rbox(el, 'ENAMEL_W', cx - 180, cy - 230, zt, cx - 168, cy + 230, zt + 55, 3, 1)
    H.rbox(el, 'ENAMEL_W', cx + 108, cy - 230, zt, cx + 120, cy + 230, zt + 55, 3, 1)
    H.rbox(el, 'ENAMEL_W', cx - 180, cy - 230, zt, cx + 120, cy - 218, zt + 55, 3, 1)
    H.rbox(el, 'ENAMEL_W', cx - 180, cy + 218, zt, cx + 120, cy + 230, zt + 55, 3, 1)
    # чайник фарфоровый
    c = (cx - 60, cy - 120, zt + 12)
    H.lathe(el, 'PORC', [(0.01, 0), (60, 0), (85, 40), (88, 80), (70, 120), (45, 135), (0.01, 136)], c, 48)
    H.lathe(el, 'BRASS_POL', [(0.01, 136), (38, 136), (30, 150), (8, 158), (12, 172), (0.01, 175)], c, 24)
    H.pipe(el, 'PORC', [(cx - 60, cy - 205, zt + 50), (cx - 60, cy - 250, zt + 110), (cx - 60, cy - 265, zt + 125)], 9, bend=30, n=12)
    H.pipe(el, 'PORC', [(cx - 60, cy - 35, zt + 115), (cx - 60, cy + 5, zt + 95), (cx - 60, cy - 30, zt + 55)], 7, bend=25, n=12)
    for (dx, dy) in ((60, -90), (60, 60), (-100, 100)):
        c = (cx + dx, cy + dy, zt + 12)
        H.lathe(el, 'PORC', [(0.01, 0), (32, 0), (40, 20), (52, 62), (49, 62), (0.01, 6)], c, 32)
    for (dx, dy) in ((-280, 60), (-220, 520)):
        c = (cx + dx, cy + dy, zt)
        H.lathe(el, 'PORC', [(0.01, 0), (45, 0), (70, 30), (82, 62), (79, 62), (0.01, 6)], c, 40)
    # ваза с гортензиями
    c = (cx + 20, cy + 120, zt)
    H.lathe(el, 'GLASS_VASE', [(0.01, 0), (40, 0), (62, 50), (60, 110), (30, 175), (26, 215), (34, 225), (0.01, 222)], c, 40)
    rng = np.random.default_rng(7)
    for i in range(3):
        b0 = V((cx + 20 + rng.normal(0, 70), cy + 120 + (i - 1) * 140, zt + 360 + rng.normal(0, 30)))
        for j in range(26):
            dv = rng.normal(0, 1, 3); dv = dv / np.linalg.norm(dv)
            H.sphere(el, 'FLOWER', tuple(b0 + dv * 85 * rng.uniform(0.4, 1.0)), rng.uniform(30, 45), 12)
        H.pipe(el, 'LEAF', [(cx + 20, cy + 120, zt + 200), tuple(b0)], 4, n=8)
    S.add(el)
